
# Task 2: Exploratory Data Analysis (EDA) - Titanic Dataset

## 🎯 Objective
Perform EDA using statistical summaries and visualizations to understand the Titanic dataset.

## 🛠 Tools Used
- Python
- Pandas, Seaborn, Matplotlib, Plotly

## 📌 Steps Performed
1. Summary statistics (mean, median, std, etc.)
2. Histograms and boxplots
3. Pairplot and correlation matrix
4. Pattern detection and visual interpretation

## 📁 Dataset
[Kaggle Titanic Dataset](https://www.kaggle.com/datasets/yasserh/titanic-dataset)

## 📤 Submission
[Google Form for Submission](https://forms.gle/8Gm83s53KbyXs3Ne9)
